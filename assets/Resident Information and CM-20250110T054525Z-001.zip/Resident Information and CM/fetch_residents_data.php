<?php
// Database connection details
$hostname = "lesterintheclouds.com";
$username = "IT112-24-M";
$password = "W2Bq@EV[SFEV";
$database = "db_brgy_app";

// Create connection
$conn = new mysqli($hostname, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the content type to JSON
header('Content-Type: application/json');

// Create the SQL query to fetch residents data from residentstb
$query = "SELECT * FROM residentstb";

// Execute the query
$result = $conn->query($query);

// Check if any rows were returned
if ($result->num_rows > 0) {
    // Initialize an array to hold the residents data
    $residents = array();

    // Loop through the results and add them to the array
    while ($row = $result->fetch_assoc()) {
        $residents[] = $row;
    }

    // Return the residents data as a JSON response
    echo json_encode($residents);
} else {
    // If no data is found, return an empty array
    echo json_encode([]);
}

// Close the database connection
$conn->close();
?>
