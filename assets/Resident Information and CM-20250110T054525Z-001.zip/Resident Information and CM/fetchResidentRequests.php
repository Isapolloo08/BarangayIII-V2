<?php
// Set the Content-Type to JSON
header('Content-Type: application/json');

// Database credentials
$hostname = "lesterintheclouds.com"; // Your database host
$username = "IT112-24-M"; // Your database username
$password = "W2Bq@EV[SFEV"; // Your database password
$database = "db_brgy_app"; // Your database name

// Create connection
$conn = new mysqli($hostname, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

// Query to fetch resident account requests
$query = "SELECT id, date_created, is_household_head, relationship, resident_name, contact_number, address, status FROM resident_requests";

// Execute the query
$result = $conn->query($query);

// Check if there are results
if ($result->num_rows > 0) {
    $requests = [];

    // Fetch all rows and push them to the $requests array
    while ($row = $result->fetch_assoc()) {
        $requests[] = [
            'id' => $row['id'],
            'dateCreated' => $row['date_created'],
            'isHouseholdHead' => $row['is_household_head'] == 1 ? true : false,
            'relationship' => $row['relationship'],
            'residentName' => $row['resident_name'],
            'contactNumber' => $row['contact_number'],
            'address' => $row['address'],
            'status' => $row['status']
        ];
    }

    // Return the requests as JSON
    echo json_encode($requests);
} else {
    // Return an empty array if no requests are found
    echo json_encode([]);
}

// Close the connection
$conn->close();
?>
