<?php
// Include database connection file
include 'db_connect.php'; 

// Query to fetch request documents from the database
$query = "SELECT * FROM request_documents"; // Adjust the query according to your database schema
$result = mysqli_query($conn, $query);

$requestDocuments = array();
while ($row = mysqli_fetch_assoc($result)) {
    $requestDocuments[] = $row;
}

// Return data as JSON
header('Content-Type: application/json');
echo json_encode($requestDocuments);
?>
