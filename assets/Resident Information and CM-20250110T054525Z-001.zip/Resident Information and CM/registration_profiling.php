<?php
// Connection details
$hostname = "lesterintheclouds.com";
$username = "IT112-24-M";
$password = "W2Bq@EV[SFEV";
$database = "db_brgy_app";

// Create a connection to MySQL
$conn = new mysqli($hostname, $username, $password, $database);

// Check for connection error
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch resident data
$sql = "SELECT * FROM residents"; // Adjust this query to match your table and fields
$result = $conn->query($sql);

$residents = array();

// Check if data is available
if ($result->num_rows > 0) {
    // Fetch each row and add to the residents array
    while($row = $result->fetch_assoc()) {
        $residents[] = $row;
    }
}

// Return the data as a JSON response
echo json_encode($residents);

// Close the connection
$conn->close();
?>
